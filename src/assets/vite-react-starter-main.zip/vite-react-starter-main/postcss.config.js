module.exports = {
  syntax: 'postcss-scss',
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
};
